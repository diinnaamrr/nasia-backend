<?php

namespace App\Enums\ExportFileNames\Admin;

enum Employee
{
    const EXPORT_CSV = 'Employees.csv';
    const EXPORT_XLSX = 'Employees.xlsx';
}
